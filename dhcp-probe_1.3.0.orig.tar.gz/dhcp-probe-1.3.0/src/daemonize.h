#ifndef DAEMONIZE_H
#define DAEMONIZE_H

void daemonize(void);

#endif /* not DAEMONIZE_H */
