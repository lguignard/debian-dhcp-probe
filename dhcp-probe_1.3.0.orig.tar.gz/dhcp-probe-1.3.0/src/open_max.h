#ifndef OPEN_MAX_H
#define OPEN_MAX_H

long open_max(void);

#endif /* not OPEN_MAX_H */
