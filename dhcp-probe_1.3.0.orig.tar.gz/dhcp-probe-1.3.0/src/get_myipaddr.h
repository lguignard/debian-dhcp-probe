#ifndef GET_MYIPADDR_H
#define GET_MYIPADDR_H

int get_myipaddr(int sockfd, char *ifname, struct in_addr *my_ipaddr);

#endif /* not GET_MYIPADDR_H */
