#ifndef GET_MYEADDR_H
#define GET_MYEADDR_H

int get_myeaddr(int sockfd, struct in_addr *my_ipaddr, struct ether_addr *my_eaddr, const char *ifname);

#endif /* not GET_MYEADDR_H */
