/* Because an empty library is not portable, our library will always contains
   at least this member.
*/
 
void
my_null_proc(void)
{
	return;
}
