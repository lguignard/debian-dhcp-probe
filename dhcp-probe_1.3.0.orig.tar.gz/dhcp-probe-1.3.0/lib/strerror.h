#ifndef STRERROR_H
#define STRERROR_H

#ifndef HAVE_STRERROR
extern char * strerror(int);
#endif

#endif /* not STRERROR_H */
